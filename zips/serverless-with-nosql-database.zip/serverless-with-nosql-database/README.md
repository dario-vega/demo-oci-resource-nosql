#serverless-with-nosql-database
